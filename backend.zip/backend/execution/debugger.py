import sys
import bdb
import io
import contextlib

class CustomDebugger(bdb.Bdb):
    def __init__(self):
        super().__init__()
        self.breakpoints = set()
        self.history = []
        self.current_step = 0
        self.variables = {}
        self.output = io.StringIO()

    def _get_locals(self, frame):
        current_vars = {}
        for name, value in frame.f_locals.items():
            if not name.startswith('__'):
                try:
                    current_vars[name] = str(value) # Convert to string for JSON serialization
                except:
                    current_vars[name] = "<unserializable>"
        return current_vars

    def user_line(self, frame):
        filename = frame.f_code.co_filename
        if filename.startswith("<") and filename != "<string>": 
             pass
        
        self.current_step += 1
        
        self.history.append({
            "step": self.current_step,
            "line": frame.f_lineno,
            "filename": filename,
            "variables": self._get_locals(frame),
            "event": "line"
        })
        
    def user_return(self, frame, return_value):
        self.current_step += 1
        self.history.append({
            "step": self.current_step,
            "line": frame.f_lineno,
            "filename": frame.f_code.co_filename,
            "variables": {}, 
            "event": "return",
            "return_value": str(return_value)
        })

    def user_exception(self, frame, exc_info):
        exc_type, exc_value, exc_traceback = exc_info
        self.current_step += 1
        self.history.append({
            "step": self.current_step,
            "line": frame.f_lineno,
            "filename": frame.f_code.co_filename,
            "event": "exception",
            "variables": self._get_locals(frame),
            "exception": {
                "type": exc_type.__name__,
                "message": str(exc_value)
            }
        })

    def run_trace(self, code, filename="<string>"):
        self.history = []
        self.current_step = 0
        
        stdout_capture = io.StringIO()
        with contextlib.redirect_stdout(stdout_capture):
            try:
                # Compile with filename to ensure stack frames have it
                compiled_code = compile(code, filename, 'exec')
                self.run(compiled_code)
            except Exception as e:
                # This catches errors in run() itself if they propagate out
                self.history.append({
                    "step": self.current_step + 1,
                    "event": "error",
                    "error": str(e)
                })
        
        return self.history, stdout_capture.getvalue()

def debug_code(code, filename="<string>"):
    debugger = CustomDebugger()
    history, output = debugger.run_trace(code, filename)
    return history, output
