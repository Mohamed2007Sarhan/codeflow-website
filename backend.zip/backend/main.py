from fastapi import FastAPI, WebSocket, UploadFile, File, Depends
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
import uvicorn
import json
import asyncio
from typing import List

from code_analyzer import analyze_code
from execution.debugger import debug_code
from database.models import init_db, get_db, Session as DbSession

app = FastAPI()

# Initialize Database
init_db()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def read_root():
    return {"message": "Code Analysis Backend Running"}

# History Endpoints
@app.get("/sessions")
def get_sessions(db: Session = Depends(get_db)):
    sessions = db.query(DbSession).order_by(DbSession.created_at.desc()).all()
    return sessions

@app.post("/sessions")
def create_session(filename: str, code: str, db: Session = Depends(get_db)):
    db_session = DbSession(filename=filename, code=code)
    db.add(db_session)
    db.commit()
    db.refresh(db_session)
    return db_session

@app.get("/sessions/{session_id}")
def get_session(session_id: int, db: Session = Depends(get_db)):
    return db.query(DbSession).filter(DbSession.id == session_id).first()

@app.websocket("/ws/analysis")
async def websocket_endpoint(websocket: WebSocket, db: Session = Depends(get_db)):
    await websocket.accept()
    try:
        data_json = await websocket.receive_text()
        data = json.loads(data_json)
        filename = data.get("filename", "unknown.py")
        code = data.get("code", "")
        
        # Save session to DB (Simplified: creating new session for every analysis)
        # In a real app, we might update existing session if editing.
        # But here we can't easily inject Depends into WebSocket, so we use SessionLocal manually or refactor.
        # For simplicity in this MVP, let's skip DB write inside WebSocket or do it manually.
        from database.models import SessionLocal
        db = SessionLocal()
        try:
            db_session = DbSession(filename=filename, code=code)
            db.add(db_session)
            db.commit()
        finally:
            db.close()
        
        steps = [
            "Building AST...",
            "Extracting Variables...",
            "Detecting Functions...",
            "Collecting Classes...",
            "Scanning Conditionals and Loops...",
            "Generating Execution Graph...",
            "Finalizing..."
        ]
        
        # Simulate initial steps
        for i in range(3):
            await websocket.send_json({
                "status": steps[i],
                "progress": (i + 1) * 10,
                "completed_steps": steps[:i]
            })
            await asyncio.sleep(0.3)

        # Perform Real Analysis
        try:
            if "files" in data:
                # Multi-file project analysis
                # Convert list of {name, content} to dict {name: content}
                files_dict = {f["name"]: f["content"] for f in data["files"]}
                from code_analyzer import analyze_project
                analysis_result = analyze_project(files_dict)
            else:
                # Single file analysis
                analysis_result = analyze_code(code, filename)
        except Exception as e:
            await websocket.send_json({"status": f"Error: {str(e)}", "progress": 0})
            return

        # Simulate remaining steps
        for i in range(3, len(steps)):
            await websocket.send_json({
                "status": steps[i],
                "progress": int(((i + 1) / len(steps)) * 100),
                "completed_steps": steps[:i]
            })
            await asyncio.sleep(0.3)
            
        await websocket.send_json({
            "status": "Done", 
            "progress": 100, 
            "completed_steps": steps,
            "result": analysis_result
        })
            
    except Exception as e:
        print(f"WebSocket error: {e}")
from execution.debugger import debug_code

@app.websocket("/ws/debug")
async def debug_endpoint(websocket: WebSocket):
    await websocket.accept()
    try:
        data_json = await websocket.receive_text()
        data = json.loads(data_json)
        code = data.get("code", "")
        filename = data.get("filename", "<string>")
        # selected_lines = data.get("selected_lines", []) # Not used in simple trace yet

        # Run the debugger
        history, output = debug_code(code, filename)
        
        # Send back the full trace (for now, later we can stream it)
        await websocket.send_json({
            "status": "Finished",
            "history": history,
            "output": output
        })
            
    except Exception as e:
        print(f"Debug WebSocket error: {e}")
        await websocket.send_json({"status": "Error", "error": str(e)})

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000, log_level="info")
