import ast

class CodeAnalyzer(ast.NodeVisitor):
    def __init__(self):
        self.variables = []
        self.functions = []
        self.classes = []
        self.imports = []
        self.loops = []
        self.conditionals = []

    def visit_Assign(self, node):
        self._add_operation(node, "Variable Assignment")
        for target in node.targets:
            if isinstance(target, ast.Name):
                self.variables.append({
                    "name": target.id,
                    "line": node.lineno,
                    "scope": "global" # Simplified for now
                })
        self.generic_visit(node)

    def visit_Expr(self, node):
        if isinstance(node.value, ast.Call):
            self._add_operation(node, "Function Call")
        else:
            self._add_operation(node, "Expression")
        self.generic_visit(node)

    def visit_Return(self, node):
        self._add_operation(node, "Return Statement")
        self.generic_visit(node)

    def visit_FunctionDef(self, node):
        self._add_operation(node, "Function Definition")
        self.functions.append({
            "name": node.name,
            "line": node.lineno,
            "args": [arg.arg for arg in node.args.args],
            "returns": "None" # Placeholder, needs deeper analysis
        })
        self.generic_visit(node)

    def visit_ClassDef(self, node):
        self._add_operation(node, "Class Definition")
        self.classes.append({
            "name": node.name,
            "line": node.lineno,
            "methods": [n.name for n in node.body if isinstance(n, ast.FunctionDef)]
        })
        self.generic_visit(node)

    def visit_For(self, node):
        self._add_operation(node, "For Loop")
        self.loops.append({
            "type": "for",
            "line": node.lineno
        })
        self.generic_visit(node)

    def visit_While(self, node):
        self._add_operation(node, "While Loop")
        self.loops.append({
            "type": "while",
            "line": node.lineno
        })
        self.generic_visit(node)

    def visit_If(self, node):
        self._add_operation(node, "If Statement")
        self.conditionals.append({
            "type": "if",
            "line": node.lineno
        })
        self.generic_visit(node)

    def _add_operation(self, node, op_type):
        self.operations.append({
            "line": node.lineno,
            "type": op_type,
            "selected": True # Default to selected
        })

from analysis.cfg_generator import generate_cfg

def analyze_code(source_code, filename=""):
    try:
        tree = ast.parse(source_code)
    except SyntaxError as e:
        return {"error": f"Syntax Error in {filename}: {str(e)}"}

    analyzer = CodeAnalyzer()
    analyzer.operations = [] # Initialize operations list
    analyzer.visit(tree)
    
    # Sort operations by line number
    analyzer.operations.sort(key=lambda x: x["line"])
    
    # Generate CFG
    cfg = generate_cfg(source_code)
    
    # Prefix node IDs with filename if provided to ensure uniqueness in project view
    if filename:
        for node in cfg["nodes"]:
            node["id"] = f"{filename}_{node['id']}"
            node["data"]["label"] = f"[{filename}] {node['data']['label']}"
            node["file"] = filename
        for edge in cfg["edges"]:
            edge["id"] = f"{filename}_{edge['id']}"
            edge["source"] = f"{filename}_{edge['source']}"
            edge["target"] = f"{filename}_{edge['target']}"

    return {
        "variables": analyzer.variables,
        "functions": analyzer.functions,
        "classes": analyzer.classes,
        "loops": analyzer.loops,
        "conditionals": analyzer.conditionals,
        "operations": analyzer.operations,
        "cfg": cfg
    }

def analyze_project(files):
    """
    files: dict of {filename: content}
    """
    project_result = {
        "variables": [],
        "functions": [],
        "classes": [],
        "loops": [],
        "conditionals": [],
        "operations": [],
        "cfg": { "nodes": [], "edges": [] }
    }
    
    for filename, content in files.items():
        result = analyze_code(content, filename)
        if "error" in result:
            continue # Skip errored files or handle gracefully
            
        project_result["variables"].extend([{**v, "file": filename} for v in result["variables"]])
        project_result["functions"].extend([{**f, "file": filename} for f in result["functions"]])
        project_result["classes"].extend([{**c, "file": filename} for c in result["classes"]])
        project_result["loops"].extend([{**l, "file": filename} for l in result["loops"]])
        project_result["conditionals"].extend([{**c, "file": filename} for c in result["conditionals"]])
        project_result["operations"].extend([{**o, "file": filename} for o in result["operations"]])
        
        project_result["cfg"]["nodes"].extend(result["cfg"]["nodes"])
        project_result["cfg"]["edges"].extend(result["cfg"]["edges"])
        
    return project_result
