import ast

class CFGGenerator(ast.NodeVisitor):
    def __init__(self):
        self.nodes = []
        self.edges = []
        self.prev_nodes = [] # List of nodes that flow into the current node
        self.last_node_id = 0

    def _new_node(self, ast_node, label, type="default"):
        self.last_node_id += 1
        node_id = str(self.last_node_id)
        self.nodes.append({
            "id": node_id,
            "data": { "label": f"{label} (L{ast_node.lineno})" },
            "position": { "x": 0, "y": 0 }, # Layout will be handled by frontend or library
            "type": type,
            "line": ast_node.lineno
        })
        return node_id

    def _add_edge(self, source, target, label=None):
        self.edges.append({
            "id": f"e{source}-{target}",
            "source": source,
            "target": target,
            "label": label
        })

    def visit_Module(self, node):
        # Start node
        start_id = "start"
        self.nodes.append({
            "id": start_id, 
            "data": { "label": "Start" }, 
            "type": "input",
            "position": { "x": 0, "y": 0 }
        })
        self.prev_nodes = [start_id]
        
        self.generic_visit(node)
        
        # End node (optional, but good for completeness)
        # For now, just leave open ends

    def visit_Assign(self, node):
        node_id = self._new_node(node, "Assign")
        for prev in self.prev_nodes:
            self._add_edge(prev, node_id)
        self.prev_nodes = [node_id]

    def visit_Expr(self, node):
        label = "Expr"
        if isinstance(node.value, ast.Call):
            label = "Call"
        node_id = self._new_node(node, label)
        for prev in self.prev_nodes:
            self._add_edge(prev, node_id)
        self.prev_nodes = [node_id]

    def visit_If(self, node):
        cond_id = self._new_node(node, "If", type="diamond") # Custom type for decision?
        for prev in self.prev_nodes:
            self._add_edge(prev, cond_id)
        
        # Branch 1: Body
        self.prev_nodes = [cond_id]
        for stmt in node.body:
            self.visit(stmt)
        body_end_nodes = self.prev_nodes
        
        # Branch 2: Else
        self.prev_nodes = [cond_id]
        for stmt in node.orelse:
            self.visit(stmt)
        else_end_nodes = self.prev_nodes
        
        # Join
        self.prev_nodes = body_end_nodes + else_end_nodes

    def visit_For(self, node):
        loop_id = self._new_node(node, "For Loop")
        for prev in self.prev_nodes:
            self._add_edge(prev, loop_id)
            
        # Body
        self.prev_nodes = [loop_id]
        for stmt in node.body:
            self.visit(stmt)
            
        # Loop back
        for prev in self.prev_nodes:
            self._add_edge(prev, loop_id, label="Loop")
            
        # Exit
        self.prev_nodes = [loop_id]

    def visit_While(self, node):
        loop_id = self._new_node(node, "While Loop")
        for prev in self.prev_nodes:
            self._add_edge(prev, loop_id)
            
        # Body
        self.prev_nodes = [loop_id]
        for stmt in node.body:
            self.visit(stmt)
            
        # Loop back
        for prev in self.prev_nodes:
            self._add_edge(prev, loop_id, label="Loop")
            
        # Exit
        self.prev_nodes = [loop_id]

    # Handle other node types generically or ignore
    # For MVP, this covers basic control flow

def generate_cfg(source_code):
    try:
        tree = ast.parse(source_code)
        generator = CFGGenerator()
        generator.visit(tree)
        return {
            "nodes": generator.nodes,
            "edges": generator.edges
        }
    except Exception as e:
        print(f"CFG Error: {e}")
        return {"nodes": [], "edges": []}
