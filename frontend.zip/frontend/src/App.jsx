import React, { useState, useEffect, useMemo } from 'react';
import './index.css';
import VariablesPanel from './components/Panels/VariablesPanel';
import FunctionsPanel from './components/Panels/FunctionsPanel';
import ClassesPanel from './components/Panels/ClassesPanel';
import ConditionalsPanel from './components/Panels/ConditionalsPanel';

import OperationChecklist from './components/OperationChecklist';
import DebugControls from './components/DebugControls';
import Timeline from './components/Timeline';
import FlowGraph from './components/FlowGraph';
import VariableGraph from './components/VariableGraph';
import ExecutionStats from './components/ExecutionStats';

import CodeEditor from './components/CodeEditor';

function App() {
  const [file, setFile] = useState(null);
  const [code, setCode] = useState(""); // Store code content
  const [isEditing, setIsEditing] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [status, setStatus] = useState("");
  const [completedSteps, setCompletedSteps] = useState([]);
  const [analysisResult, setAnalysisResult] = useState(null);
  const [showChecklist, setShowChecklist] = useState(false);

  // Debug State
  const [debugHistory, setDebugHistory] = useState([]);
  const [currentStep, setCurrentStep] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const [bottomTab, setBottomTab] = useState('timeline');

  // History State
  const [sessions, setSessions] = useState([]);

  useEffect(() => {
    fetchSessions();
  }, []);

  const fetchSessions = async () => {
    try {
      const response = await fetch('http://localhost:8000/sessions');
      if (response.ok) {
        const data = await response.json();
        setSessions(data);
      }
    } catch (error) {
      console.error("Failed to fetch sessions:", error);
    }
  };

  const loadSession = (session) => {
    setCode(session.code);
    setFile({ name: session.filename }); // Mock file object
    startAnalysis(session.code);
  };

  const handleFileUpload = (event) => {
    const uploadedFile = event.target.files[0];
    setFile(uploadedFile);
    startAnalysis(uploadedFile);
  };

  const startAnalysis = (fileOrCode) => {
    setAnalyzing(true);
    setProgress(0);
    setCompletedSteps([]);
    setAnalysisResult(null);
    setShowChecklist(false);
    setDebugHistory([]);
    setCurrentStep(0);

    // Handle both File object and raw code string
    if (fileOrCode instanceof File) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const content = e.target.result;
        setCode(content);
        sendAnalysisRequest(fileOrCode.name, content);
      };
      reader.readAsText(fileOrCode);
    } else {
      // It's a string (re-run)
      setCode(fileOrCode);
      sendAnalysisRequest(file ? file.name : "edited.py", fileOrCode);
    }
  };

  const sendAnalysisRequest = (filename, content) => {
    const ws = new WebSocket('ws://localhost:8000/ws/analysis');

    ws.onopen = () => {
      ws.send(JSON.stringify({ filename: filename, code: content }));
    };

    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      setStatus(data.status);
      setProgress(data.progress);
      if (data.completed_steps) {
        setCompletedSteps(data.completed_steps);
      }
      if (data.result) {
        console.log("Analysis Result:", data.result);
        setAnalysisResult(data.result);
      }
      if (data.progress === 100) {
        setTimeout(() => {
          setAnalyzing(false);
          setShowChecklist(true);
        }, 1000);
      }
    };
  };

  const startDebugging = (selectedLines) => {
    const ws = new WebSocket('ws://localhost:8000/ws/debug');

    ws.onopen = () => {
      ws.send(JSON.stringify({
        code: code,
        filename: file ? file.name : "unknown.py",
        selected_lines: selectedLines
      }));
    };

    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      if (data.status === "Finished") {
        setDebugHistory(data.history);
        setCurrentStep(0);
        setIsRunning(false); // Auto-pause at start
      }
    };
  };

  // Debug Controls
  const handleStepForward = () => {
    if (currentStep < debugHistory.length - 1) {
      setCurrentStep(prev => prev + 1);
    }
  };

  const handleStepBack = () => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1);
    }
  };

  // Get current variables based on step
  const getCurrentVariables = () => {
    if (!debugHistory || debugHistory.length === 0) return analysisResult?.variables;
    // Find the last 'line' event up to current step that has variables
    // Or just take the variables from the current step if it's a line event
    // For simplicity, let's assume the backend returns the FULL state at each step (it currently returns locals)
    // We might need to merge with previous steps if backend only returns diffs.
    // My backend returns `current_vars` which are all locals.

    const stepData = debugHistory[currentStep];
    if (stepData && stepData.variables) {
      return Object.entries(stepData.variables).map(([name, value]) => ({
        name,
        value, // We need to display this value
        line: stepData.line,
        scope: "local"
      }));
    }
    return [];
  };

  return (
    <div className="flex h-screen bg-gray-900 text-white font-sans overflow-hidden">
      {/* Left Sidebar - History */}
      <div className="w-64 bg-gray-800 border-r border-gray-700 flex flex-col">
        <div className="p-4 border-b border-gray-700 font-bold text-lg flex justify-between items-center">
          <span>History</span>
          <button onClick={fetchSessions} className="text-xs text-blue-400 hover:text-blue-300">Refresh</button>
        </div>
        <div className="flex-1 overflow-y-auto p-2 space-y-2">
          {sessions.length === 0 ? (
            <div className="text-gray-400 text-sm italic p-2">No previous sessions</div>
          ) : (
            sessions.map((session) => (
              <div
                key={session.id}
                onClick={() => loadSession(session)}
                className="p-3 rounded bg-gray-700/50 hover:bg-gray-700 cursor-pointer transition border border-gray-600/50"
              >
                <div className="font-medium text-sm text-gray-200 truncate">{session.filename}</div>
                <div className="text-xs text-gray-500 mt-1">
                  {new Date(session.created_at).toLocaleString()}
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Top Bar */}
        <div className="h-12 bg-gray-800 border-b border-gray-700 flex items-center px-4 space-x-4">
          <label className="cursor-pointer bg-blue-600 hover:bg-blue-500 px-3 py-1 rounded text-sm font-medium transition flex items-center">
            <span className="mr-2">📄</span> Open File
            <input type="file" className="hidden" onChange={handleFileUpload} />
          </label>

          <label className="cursor-pointer bg-green-600 hover:bg-green-500 px-3 py-1 rounded text-sm font-medium transition flex items-center">
            <span className="mr-2">📂</span> Open Folder
            <input
              type="file"
              className="hidden"
              webkitdirectory=""
              directory=""
              multiple
              onChange={(e) => {
                const files = Array.from(e.target.files);
                const pythonFiles = files.filter(f => f.name.endsWith('.py'));

                if (pythonFiles.length === 0) {
                  alert("No Python files found in this folder.");
                  return;
                }

                // Read all files
                const filePromises = pythonFiles.map(file => {
                  return new Promise((resolve) => {
                    const reader = new FileReader();
                    reader.onload = (e) => resolve({ name: file.webkitRelativePath || file.name, content: e.target.result });
                    reader.readAsText(file);
                  });
                });

                Promise.all(filePromises).then(results => {
                  console.log("Loaded project files:", results);
                  if (results.length > 0) {
                    // Set the first file as active for viewing
                    setCode(results[0].content);
                    setFile({ name: results[0].name });

                    // Send all files for analysis
                    const ws = new WebSocket('ws://localhost:8000/ws/analysis');
                    ws.onopen = () => {
                      ws.send(JSON.stringify({ files: results }));
                    };
                    // Attach same message handler
                    ws.onmessage = (event) => {
                      const data = JSON.parse(event.data);
                      setStatus(data.status);
                      setProgress(data.progress);
                      if (data.completed_steps) setCompletedSteps(data.completed_steps);
                      if (data.result) {
                        console.log("Project Analysis Result:", data.result);
                        setAnalysisResult(data.result);
                      }
                      if (data.progress === 100) {
                        setTimeout(() => {
                          setAnalyzing(false);
                          setShowChecklist(true);
                        }, 1000);
                      }
                    };

                    setAnalyzing(true);
                    setProgress(0);
                    setCompletedSteps([]);
                    setAnalysisResult(null);
                    setShowChecklist(false);
                    setDebugHistory([]);
                    setCurrentStep(0);
                  }
                });
              }}
            />
          </label>

          {debugHistory.length > 0 && (
            <DebugControls
              onStepBack={handleStepBack}
              onStepForward={handleStepForward}
              onRun={() => setIsRunning(!isRunning)} // Toggle run
              onPause={() => setIsRunning(false)}
              isRunning={isRunning}
              currentStep={currentStep}
              totalSteps={debugHistory.length}
            />
          )}

          <div className="flex-1"></div>

          {analysisResult && (
            <button
              onClick={() => {
                const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify({ analysis: analysisResult, history: debugHistory }, null, 2));
                const downloadAnchorNode = document.createElement('a');
                downloadAnchorNode.setAttribute("href", dataStr);
                downloadAnchorNode.setAttribute("download", "analysis_export.json");
                document.body.appendChild(downloadAnchorNode);
                downloadAnchorNode.click();
                downloadAnchorNode.remove();
              }}
              className="text-xs bg-gray-700 hover:bg-gray-600 px-3 py-1 rounded text-gray-300 transition mr-4"
            >
              Export JSON
            </button>
          )}

          <span className="text-sm text-gray-400">{file ? file.name : "No file selected"}</span>
        </div>

        {/* Visualization Area */}
        <div className="flex-1 bg-gray-900 relative flex">
          {/* Code Viewer */}
          <div className="w-1/2 border-r border-gray-700 font-mono text-sm overflow-hidden relative bg-gray-900">
            <CodeEditor
              code={code}
              onSave={(newCode) => startAnalysis(newCode)}
              currentLine={debugHistory[currentStep]?.line}
              isEditing={isEditing}
              setIsEditing={setIsEditing}
            />

            {!isEditing && debugHistory.length > 0 && (
              <div className="absolute bottom-4 right-4 p-2 bg-gray-800/90 rounded border border-gray-700 text-xs shadow-lg backdrop-blur pointer-events-none">
                <div className="text-blue-400 font-bold">Step {currentStep + 1}</div>
                <div className="text-gray-300">{debugHistory[currentStep]?.event}</div>
              </div>
            )}
          </div>

          {/* Graph/Visualizer */}
          <div className="w-1/2 p-4 flex items-center justify-center text-gray-600 bg-gray-900 border-l border-gray-700 overflow-hidden">
            <FlowGraph
              cfg={analysisResult?.cfg}
              currentLine={debugHistory[currentStep]?.line}
              executionStatus={useMemo(() => {
                if (!debugHistory) return {};
                const status = {};
                debugHistory.forEach(step => {
                  // Use composite key if filename exists, otherwise just line
                  const key = step.filename ? `${step.filename}:${step.line}` : step.line;

                  if (step.event === 'exception' || step.event === 'error') {
                    status[key] = { type: 'error', error: step.exception?.message || step.error || "Error" };
                  } else {
                    // Only mark as success if not already marked as error
                    if (!status[key]) {
                      status[key] = { type: 'success' };
                    }
                  }
                });
                return status;
              }, [debugHistory])}
            />
          </div>

          {/* Loading Modal Overlay */}
          {analyzing && (
            <div className="absolute inset-0 bg-black/80 flex items-center justify-center z-50 backdrop-blur-sm">
              <div className="bg-gray-800 p-8 rounded-xl shadow-2xl w-96 border border-gray-700">
                <h2 className="text-xl font-bold mb-4 text-blue-400">Analyzing Code...</h2>
                <div className="mb-2 flex justify-between text-sm text-gray-300">
                  <span>{status}</span>
                  <span>{progress}%</span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-2.5 mb-6">
                  <div
                    className="bg-blue-600 h-2.5 rounded-full transition-all duration-300 ease-out"
                    style={{ width: `${progress}%` }}
                  ></div>
                </div>
                <div className="space-y-1">
                  {completedSteps.map((step, idx) => (
                    <div key={idx} className="text-xs text-green-400 flex items-center">
                      <span className="mr-2">✓</span> {step}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Operation Checklist Modal */}
          {showChecklist && analysisResult?.operations && (
            <OperationChecklist
              operations={analysisResult.operations}
              onConfirm={(selectedLines) => {
                console.log("Selected lines for debug:", selectedLines);
                setShowChecklist(false);
                startDebugging(selectedLines);
              }}
              onCancel={() => setShowChecklist(false)}
            />
          )}
          {/* Bottom Panel Overlay */}
          <div className="fixed bottom-0 left-64 right-72 h-64 bg-gray-800/95 backdrop-blur border-t border-gray-700 flex flex-col z-40 transition-transform duration-300">
            <div className="flex border-b border-gray-700">
              <button
                onClick={() => setBottomTab('timeline')}
                className={`px-4 py-1 text-xs font-medium uppercase tracking-wider ${bottomTab === 'timeline' ? 'bg-gray-700 text-white' : 'text-gray-400 hover:text-gray-200'}`}
              >
                Execution Timeline
              </button>
              <button
                onClick={() => setBottomTab('graph')}
                className={`px-4 py-1 text-xs font-medium uppercase tracking-wider ${bottomTab === 'graph' ? 'bg-gray-700 text-white' : 'text-gray-400 hover:text-gray-200'}`}
              >
                Variable Graph
              </button>
              <button
                onClick={() => setBottomTab('stats')}
                className={`px-4 py-1 text-xs font-medium uppercase tracking-wider ${bottomTab === 'stats' ? 'bg-gray-700 text-white' : 'text-gray-400 hover:text-gray-200'}`}
              >
                Stats & Decisions
              </button>
            </div>

            <div className="flex-1 overflow-hidden p-2">
              {bottomTab === 'timeline' && (
                <Timeline
                  history={debugHistory}
                  currentStep={currentStep}
                  onStepClick={setCurrentStep}
                />
              )}
              {bottomTab === 'graph' && (
                <VariableGraph history={debugHistory} />
              )}
              {bottomTab === 'stats' && (
                <ExecutionStats history={debugHistory} analysisResult={analysisResult} />
              )}
            </div>
          </div>
        </div>

        {/* Bottom Panel */}

      </div>

      {/* Right Sidebar - Structured Panels */}
      <div className="w-72 bg-gray-800 border-l border-gray-700 flex flex-col">
        <div className="p-2 bg-gray-750 border-b border-gray-700 font-semibold text-sm">Variables</div>
        <div className="flex-1 p-2 overflow-y-auto border-b border-gray-700">
          <VariablesPanel variables={analysisResult?.variables} />
        </div>

        <div className="p-2 bg-gray-750 border-b border-gray-700 font-semibold text-sm">Functions</div>
        <div className="flex-1 p-2 overflow-y-auto border-b border-gray-700">
          <FunctionsPanel functions={analysisResult?.functions} />
        </div>

        <div className="p-2 bg-gray-750 border-b border-gray-700 font-semibold text-sm">Classes</div>
        <div className="flex-1 p-2 overflow-y-auto border-b border-gray-700">
          <ClassesPanel classes={analysisResult?.classes} />
        </div>

        <div className="p-2 bg-gray-750 border-b border-gray-700 font-semibold text-sm">Logic</div>
        <div className="flex-1 p-2 overflow-y-auto">
          <ConditionalsPanel loops={analysisResult?.loops} conditionals={analysisResult?.conditionals} />
        </div>
      </div>
    </div>
  );
}

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null, errorInfo: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    this.setState({ error, errorInfo });
    console.error("Uncaught error:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="p-8 bg-gray-900 text-red-500 h-screen overflow-auto">
          <h1 className="text-2xl font-bold mb-4">Something went wrong.</h1>
          <pre className="bg-gray-800 p-4 rounded border border-red-700 whitespace-pre-wrap">
            {this.state.error && this.state.error.toString()}
            <br />
            {this.state.errorInfo && this.state.errorInfo.componentStack}
          </pre>
        </div>
      );
    }

    return this.props.children;
  }
}

export default function AppWrapper() {
  return (
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  );
}
