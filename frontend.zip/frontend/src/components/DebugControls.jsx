import React from 'react';

const DebugControls = ({ onStepBack, onStepForward, onRun, onPause, isRunning, currentStep, totalSteps }) => {
    return (
        <div className="flex items-center space-x-2 bg-gray-800 p-1 rounded border border-gray-700">
            <button
                onClick={onStepBack}
                disabled={currentStep <= 0}
                className="p-1 hover:bg-gray-700 rounded disabled:opacity-50 disabled:cursor-not-allowed"
                title="Step Back"
            >
                ⏮
            </button>
            <button
                onClick={onPause}
                className={`p-1 hover:bg-gray-700 rounded ${!isRunning ? 'text-gray-500' : 'text-yellow-500'}`}
                title="Pause"
            >
                ⏸
            </button>
            <button
                onClick={onRun}
                className={`p-1 hover:bg-gray-700 rounded ${isRunning ? 'text-green-500' : 'text-gray-300'}`}
                title="Run"
            >
                ▶
            </button>
            <button
                onClick={onStepForward}
                disabled={currentStep >= totalSteps - 1}
                className="p-1 hover:bg-gray-700 rounded disabled:opacity-50 disabled:cursor-not-allowed"
                title="Step Forward"
            >
                ⏭
            </button>
            <div className="text-xs text-gray-400 ml-2 font-mono">
                Step {currentStep + 1} / {totalSteps}
            </div>
        </div>
    );
};

export default DebugControls;
