import React from 'react';

const ClassesPanel = ({ classes }) => {
    if (!classes || classes.length === 0) {
        return <div className="p-4 text-gray-500 text-xs italic">No classes detected.</div>;
    }

    return (
        <div className="w-full space-y-2 p-2">
            {classes.map((cls, idx) => (
                <div key={idx} className="bg-gray-700/30 rounded border border-gray-700 p-2">
                    <div className="flex justify-between items-center mb-1">
                        <span className="text-purple-300 font-mono text-sm font-bold">{cls.name}</span>
                        <span className="text-xs text-gray-500">Line {cls.line}</span>
                    </div>
                    <div className="pl-2 border-l-2 border-gray-600 mt-1">
                        <div className="text-xs text-gray-400 mb-1">Methods:</div>
                        {cls.methods.length > 0 ? (
                            <ul className="list-disc list-inside text-xs text-gray-300">
                                {cls.methods.map((method, mIdx) => (
                                    <li key={mIdx}>{method}</li>
                                ))}
                            </ul>
                        ) : (
                            <span className="text-xs text-gray-500 italic">No methods</span>
                        )}
                    </div>
                </div>
            ))}
        </div>
    );
};

export default ClassesPanel;
