import React from 'react';

const ConditionalsPanel = ({ loops, conditionals }) => {
    if ((!loops || loops.length === 0) && (!conditionals || conditionals.length === 0)) {
        return <div className="p-4 text-gray-500 text-xs italic">No loops or conditionals detected.</div>;
    }

    return (
        <div className="w-full space-y-2 p-2">
            {/* Loops */}
            {loops && loops.length > 0 && (
                <div className="mb-2">
                    <div className="text-xs font-bold text-gray-400 mb-1 uppercase">Loops</div>
                    {loops.map((loop, idx) => (
                        <div key={`loop-${idx}`} className="bg-gray-700/30 rounded border border-gray-700 p-2 mb-1 flex justify-between items-center">
                            <span className="text-orange-300 font-mono text-sm">{loop.type} loop</span>
                            <span className="text-xs text-gray-500">Line {loop.line}</span>
                        </div>
                    ))}
                </div>
            )}

            {/* Conditionals */}
            {conditionals && conditionals.length > 0 && (
                <div>
                    <div className="text-xs font-bold text-gray-400 mb-1 uppercase">Conditionals</div>
                    {conditionals.map((cond, idx) => (
                        <div key={`cond-${idx}`} className="bg-gray-700/30 rounded border border-gray-700 p-2 mb-1 flex justify-between items-center">
                            <span className="text-green-300 font-mono text-sm">{cond.type} statement</span>
                            <span className="text-xs text-gray-500">Line {cond.line}</span>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

export default ConditionalsPanel;
