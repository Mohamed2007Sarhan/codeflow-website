import React from 'react';

const VariablesPanel = ({ variables }) => {
    if (!variables || variables.length === 0) {
        return <div className="p-4 text-gray-500 text-xs italic">No variables detected.</div>;
    }

    return (
        <div className="w-full">
            <table className="w-full text-left border-collapse">
                <thead>
                    <tr className="text-xs text-gray-400 border-b border-gray-700">
                        <th className="p-2 font-medium">Name</th>
                        <th className="p-2 font-medium">Line</th>
                        <th className="p-2 font-medium">Scope</th>
                    </tr>
                </thead>
                <tbody>
                    {variables.map((v, idx) => (
                        <tr key={idx} className="border-b border-gray-700/50 hover:bg-gray-700/30 transition text-sm">
                            <td className="p-2 text-blue-300 font-mono">{v.name}</td>
                            <td className="p-2 text-gray-400">{v.line}</td>
                            <td className="p-2 text-gray-500 text-xs">{v.scope}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default VariablesPanel;
