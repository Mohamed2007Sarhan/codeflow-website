import React from 'react';

const FunctionsPanel = ({ functions }) => {
    if (!functions || functions.length === 0) {
        return <div className="p-4 text-gray-500 text-xs italic">No functions detected.</div>;
    }

    return (
        <div className="w-full space-y-2 p-2">
            {functions.map((func, idx) => (
                <div key={idx} className="bg-gray-700/30 rounded border border-gray-700 p-2 hover:border-blue-500/50 transition">
                    <div className="flex justify-between items-center mb-1">
                        <span className="text-yellow-300 font-mono text-sm font-bold">{func.name}</span>
                        <span className="text-xs text-gray-500">Line {func.line}</span>
                    </div>
                    <div className="text-xs text-gray-400">
                        <span className="text-gray-500">Args:</span> {func.args.length > 0 ? func.args.join(', ') : 'None'}
                    </div>
                </div>
            ))}
        </div>
    );
};

export default FunctionsPanel;
