import React, { useState, useEffect } from 'react';

const CodeEditor = ({ code, onSave, currentLine, isEditing, setIsEditing }) => {
    const [editableCode, setEditableCode] = useState(code);

    useEffect(() => {
        setEditableCode(code);
    }, [code]);

    const handleSave = () => {
        onSave(editableCode);
        setIsEditing(false);
    };

    return (
        <div className="h-full flex flex-col relative">
            <div className="flex justify-between items-center mb-2 bg-gray-800 p-1 rounded">
                <span className="text-xs text-gray-400 font-bold px-2">SOURCE CODE</span>
                {isEditing ? (
                    <div className="space-x-2">
                        <button
                            onClick={() => setIsEditing(false)}
                            className="px-2 py-1 text-xs text-gray-300 hover:text-white"
                        >
                            Cancel
                        </button>
                        <button
                            onClick={handleSave}
                            className="px-2 py-1 text-xs bg-blue-600 text-white rounded hover:bg-blue-500"
                        >
                            Save & Re-run
                        </button>
                    </div>
                ) : (
                    <button
                        onClick={() => setIsEditing(true)}
                        className="px-2 py-1 text-xs bg-gray-700 text-gray-300 rounded hover:bg-gray-600"
                    >
                        Edit Code
                    </button>
                )}
            </div>

            <div className="flex-1 overflow-auto relative font-mono text-sm bg-gray-900">
                {isEditing ? (
                    <textarea
                        value={editableCode}
                        onChange={(e) => setEditableCode(e.target.value)}
                        className="w-full h-full bg-gray-900 text-gray-300 p-4 outline-none resize-none font-mono"
                        spellCheck="false"
                    />
                ) : (
                    <div className="p-4 relative min-h-full">
                        {/* Line Numbers and Code */}
                        {editableCode.split('\n').map((line, idx) => {
                            const lineNum = idx + 1;
                            const isCurrent = lineNum === currentLine;
                            return (
                                <div
                                    key={idx}
                                    className={`flex ${isCurrent ? 'bg-blue-900/30' : ''}`}
                                >
                                    <span className="w-8 text-gray-600 text-right mr-4 select-none">{lineNum}</span>
                                    <pre className={`flex-1 whitespace-pre-wrap ${isCurrent ? 'text-blue-100' : 'text-gray-300'}`}>
                                        {line}
                                    </pre>
                                    {isCurrent && (
                                        <div className="absolute left-0 w-1 h-5 bg-blue-500 mt-0.5"></div>
                                    )}
                                </div>
                            );
                        })}
                    </div>
                )}
            </div>
        </div>
    );
};

export default CodeEditor;
