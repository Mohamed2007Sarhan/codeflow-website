import React, { useState, useEffect } from 'react';

const OperationChecklist = ({ operations, onConfirm, onCancel }) => {
    const [selectedOps, setSelectedOps] = useState([]);

    useEffect(() => {
        if (operations) {
            setSelectedOps(operations.map(op => op.line)); // Default all selected
        }
    }, [operations]);

    const toggleOp = (line) => {
        setSelectedOps(prev =>
            prev.includes(line)
                ? prev.filter(l => l !== line)
                : [...prev, line]
        );
    };

    const handleConfirm = () => {
        onConfirm(selectedOps);
    };

    if (!operations) return null;

    return (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 backdrop-blur-sm">
            <div className="bg-gray-800 rounded-xl shadow-2xl w-[600px] max-h-[80vh] flex flex-col border border-gray-700">
                <div className="p-6 border-b border-gray-700">
                    <h2 className="text-xl font-bold text-white">Select Operations to Debug</h2>
                    <p className="text-gray-400 text-sm mt-1">Uncheck operations you want to skip during debugging.</p>
                </div>

                <div className="flex-1 overflow-y-auto p-6 space-y-2">
                    {operations.map((op, idx) => (
                        <div
                            key={idx}
                            className={`flex items-center p-3 rounded border cursor-pointer transition ${selectedOps.includes(op.line)
                                ? 'bg-blue-900/20 border-blue-500/50'
                                : 'bg-gray-700/30 border-gray-700 hover:bg-gray-700/50'
                                }`}
                            onClick={() => toggleOp(op.line)}
                        >
                            <div className={`w-5 h-5 rounded border flex items-center justify-center mr-4 ${selectedOps.includes(op.line) ? 'bg-blue-600 border-blue-600' : 'border-gray-500'
                                }`}>
                                {selectedOps.includes(op.line) && <span className="text-white text-xs">✓</span>}
                            </div>
                            <div className="flex-1">
                                <div className="flex justify-between items-center">
                                    <span className="text-gray-200 font-medium">Line {op.line}</span>
                                    <span className="text-xs text-gray-500 uppercase tracking-wider">{op.type}</span>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>

                <div className="p-6 border-t border-gray-700 flex justify-end space-x-3">
                    <button
                        onClick={onCancel}
                        className="px-4 py-2 rounded text-gray-300 hover:text-white hover:bg-gray-700 transition"
                    >
                        Cancel
                    </button>
                    <button
                        onClick={handleConfirm}
                        className="px-6 py-2 rounded bg-blue-600 hover:bg-blue-500 text-white font-medium transition shadow-lg shadow-blue-900/20"
                    >
                        Run Debug on Selected ({selectedOps.length})
                    </button>
                </div>
            </div>
        </div>
    );
};

export default OperationChecklist;
