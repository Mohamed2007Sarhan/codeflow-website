import React, { useMemo } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const ExecutionStats = ({ history, analysisResult }) => {
    const stats = useMemo(() => {
        if (!history || history.length === 0) return { functionCalls: [], decisions: [] };

        // 1. Function Call Counts
        const callCounts = {};
        history.forEach(step => {
            if (step.event === 'call') {
                // The function name isn't directly in the step event for 'call' in standard bdb, 
                // but usually it's the co_name. My backend debugger might need to ensure it sends function name.
                // Let's assume the 'line' content or a specific field has it. 
                // If not, we can try to infer from the line number if we have the function map.
                // For this MVP, let's check if 'func_name' is in the step data (I should check debugger.py).
                // If not, I'll rely on the analysisResult to map line numbers to functions.

                // Actually, let's look at the debugger.py output structure in my memory.
                // It captures: 'step': i, 'line': line_num, 'event': event, 'variables': ...
                // It doesn't explicitly send function name in the event.
                // But I have analysisResult.functions which has { name: { start_line, end_line } }

                // Let's map line numbers to functions.
                const line = step.line;
                if (analysisResult && analysisResult.functions) {
                    Object.entries(analysisResult.functions).forEach(([name, info]) => {
                        if (line >= info.start_line && line <= info.end_line) {
                            callCounts[name] = (callCounts[name] || 0) + 1;
                        }
                    });
                }
            }
        });

        const functionCalls = Object.entries(callCounts).map(([name, count]) => ({
            name,
            count
        }));

        // 2. Branch Decisions (Simplified)
        // Find 'if' statements in analysisResult and check if they were executed
        const decisions = [];
        if (analysisResult && analysisResult.conditionals) {
            analysisResult.conditionals.forEach(cond => {
                // Check if the condition line was visited
                const visitedIndex = history.findIndex(h => h.line === cond.line);
                if (visitedIndex !== -1 && visitedIndex < history.length - 1) {
                    const nextStep = history[visitedIndex + 1];
                    // If next line is line + 1, likely True (or just entered block). 
                    // This is a heuristic. A better way is to see if we entered the body.
                    // But for now, just knowing it was evaluated is good.
                    decisions.push({
                        line: cond.line,
                        type: 'If Statement',
                        evaluated: 'Yes',
                        next_line: nextStep.line
                    });
                }
            });
        }

        return { functionCalls, decisions };
    }, [history, analysisResult]);

    return (
        <div className="flex h-full text-gray-300 space-x-4">
            {/* Function Calls Chart */}
            <div className="w-1/2 flex flex-col">
                <h3 className="text-sm font-bold mb-2 text-blue-400">Function Call Frequency</h3>
                <div className="flex-1 bg-gray-900/50 rounded border border-gray-700 p-2">
                    {stats.functionCalls.length > 0 ? (
                        <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={stats.functionCalls}>
                                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                                <XAxis dataKey="name" stroke="#9ca3af" fontSize={10} />
                                <YAxis stroke="#9ca3af" fontSize={10} />
                                <Tooltip
                                    contentStyle={{ backgroundColor: '#1f2937', borderColor: '#374151', color: '#f3f4f6' }}
                                    cursor={{ fill: '#374151' }}
                                />
                                <Bar dataKey="count" fill="#3b82f6" />
                            </BarChart>
                        </ResponsiveContainer>
                    ) : (
                        <div className="h-full flex items-center justify-center text-xs text-gray-500 italic">
                            No function calls detected.
                        </div>
                    )}
                </div>
            </div>

            {/* Decision Log */}
            <div className="w-1/2 flex flex-col">
                <h3 className="text-sm font-bold mb-2 text-green-400">Branch Decisions</h3>
                <div className="flex-1 bg-gray-900/50 rounded border border-gray-700 overflow-y-auto p-2">
                    {stats.decisions.length > 0 ? (
                        <table className="w-full text-xs text-left">
                            <thead className="text-gray-500 border-b border-gray-700">
                                <tr>
                                    <th className="pb-1">Line</th>
                                    <th className="pb-1">Type</th>
                                    <th className="pb-1">Next Line</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-800">
                                {stats.decisions.map((d, idx) => (
                                    <tr key={idx} className="hover:bg-gray-800/50">
                                        <td className="py-1">{d.line}</td>
                                        <td className="py-1">{d.type}</td>
                                        <td className="py-1">{d.next_line}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    ) : (
                        <div className="h-full flex items-center justify-center text-xs text-gray-500 italic">
                            No branch decisions recorded.
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default ExecutionStats;
