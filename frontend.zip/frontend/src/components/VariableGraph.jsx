import React, { useMemo } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const VariableGraph = ({ history }) => {
    const data = useMemo(() => {
        if (!history || history.length === 0) return [];

        // Extract all unique numeric variable names across history
        const numericVars = new Set();
        history.forEach(step => {
            if (step.variables) {
                Object.entries(step.variables).forEach(([name, value]) => {
                    // Check if value looks like a number
                    if (!isNaN(parseFloat(value)) && isFinite(value)) {
                        numericVars.add(name);
                    }
                });
            }
        });

        // Transform history into chart data
        return history.map(step => {
            const point = { step: step.step };
            if (step.variables) {
                Object.entries(step.variables).forEach(([name, value]) => {
                    if (numericVars.has(name)) {
                        point[name] = parseFloat(value);
                    }
                });
            }
            return point;
        });
    }, [history]);

    if (!data || data.length === 0) {
        return (
            <div className="h-full flex items-center justify-center text-gray-500 text-xs italic">
                No numeric variables to graph.
            </div>
        );
    }

    const colors = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'];

    return (
        <div className="h-full w-full p-2">
            <ResponsiveContainer width="100%" height="100%">
                <LineChart data={data}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                    <XAxis dataKey="step" stroke="#9ca3af" fontSize={10} />
                    <YAxis stroke="#9ca3af" fontSize={10} />
                    <Tooltip
                        contentStyle={{ backgroundColor: '#1f2937', borderColor: '#374151', color: '#f3f4f6' }}
                        itemStyle={{ fontSize: '12px' }}
                    />
                    <Legend wrapperStyle={{ fontSize: '12px' }} />
                    {Object.keys(data[0] || {}).filter(k => k !== 'step').map((key, idx) => (
                        <Line
                            key={key}
                            type="monotone"
                            dataKey={key}
                            stroke={colors[idx % colors.length]}
                            strokeWidth={2}
                            dot={false}
                        />
                    ))}
                </LineChart>
            </ResponsiveContainer>
        </div>
    );
};

export default VariableGraph;
