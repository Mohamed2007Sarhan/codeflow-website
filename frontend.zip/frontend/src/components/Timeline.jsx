import React, { useEffect, useRef } from 'react';

const Timeline = ({ history, currentStep, onStepClick }) => {
    const scrollRef = useRef(null);

    useEffect(() => {
        if (scrollRef.current && history && history.length > 0) {
            // Scroll to current step
            const element = scrollRef.current.children[currentStep];
            if (element) {
                element.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
            }
        }
    }, [currentStep, history]);

    if (!history || history.length === 0) {
        return (
            <div className="h-full flex items-center justify-center text-gray-500 text-xs italic">
                No execution history available. Run debug to generate timeline.
            </div>
        );
    }

    return (
        <div className="h-full flex flex-col">
            <div className="text-xs font-bold text-gray-400 mb-2 uppercase tracking-wider flex justify-between">
                <span>Execution Timeline</span>
                <span>{history.length} Steps</span>
            </div>
            <div className="flex-1 overflow-x-auto flex space-x-2 pb-2 px-2" ref={scrollRef}>
                {history.map((step, idx) => (
                    <div
                        key={idx}
                        onClick={() => onStepClick(idx)}
                        className={`flex-shrink-0 w-32 h-24 rounded border p-2 cursor-pointer transition relative group ${currentStep === idx
                            ? 'bg-blue-900/30 border-blue-500 ring-1 ring-blue-500'
                            : 'bg-gray-700/30 border-gray-600/50 hover:bg-gray-700/50'
                            }`}
                    >
                        <div className="flex justify-between items-start mb-1">
                            <span className={`text-xs font-bold ${currentStep === idx ? 'text-blue-400' : 'text-gray-400'}`}>
                                Step {step.step}
                            </span>
                            <span className="text-[10px] text-gray-500">L{step.line}</span>
                        </div>
                        <div className="text-xs text-gray-300 truncate font-mono mb-1">
                            {step.event}
                        </div>
                        {step.event === 'line' && Object.keys(step.variables).length > 0 && (
                            <div className="text-[10px] text-gray-500 truncate">
                                Vars: {Object.keys(step.variables).join(', ')}
                            </div>
                        )}
                        {step.event === 'return' && (
                            <div className="text-[10px] text-purple-400 truncate">
                                Ret: {step.return_value}
                            </div>
                        )}
                        {step.event === 'exception' && (
                            <div className="text-[10px] text-red-400 truncate font-bold" title={`${step.exception.type}: ${step.exception.message}`}>
                                Err: {step.exception.type}: {step.exception.message}
                            </div>
                        )}

                        {/* Connector Line (Visual only) */}
                        {idx < history.length - 1 && (
                            <div className="absolute top-1/2 -right-3 w-2 h-0.5 bg-gray-700"></div>
                        )}
                    </div>
                ))}
            </div>
        </div>
    );
};

export default Timeline;
