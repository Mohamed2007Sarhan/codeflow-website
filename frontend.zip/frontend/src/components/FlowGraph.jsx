import React, { useEffect, useMemo } from 'react';
import ReactFlow, {
    useNodesState,
    useEdgesState,
    Background,
    Controls,
    MiniMap,
    MarkerType
} from 'reactflow';
import 'reactflow/dist/style.css';
import dagre from 'dagre';

const dagreGraph = new dagre.graphlib.Graph();
dagreGraph.setDefaultEdgeLabel(() => ({}));

const nodeWidth = 172;
const nodeHeight = 36;

const getLayoutedElements = (nodes, edges, direction = 'TB') => {
    dagreGraph.setGraph({ rankdir: direction });

    nodes.forEach((node) => {
        dagreGraph.setNode(node.id, { width: nodeWidth, height: nodeHeight });
    });

    edges.forEach((edge) => {
        dagreGraph.setEdge(edge.source, edge.target);
    });

    dagre.layout(dagreGraph);

    const layoutedNodes = nodes.map((node) => {
        const nodeWithPosition = dagreGraph.node(node.id);
        node.targetPosition = 'top';
        node.sourcePosition = 'bottom';

        node.position = {
            x: nodeWithPosition.x - nodeWidth / 2,
            y: nodeWithPosition.y - nodeHeight / 2,
        };

        return node;
    });

    return { nodes: layoutedNodes, edges };
};

const FlowGraph = ({ cfg, currentLine, executionStatus }) => {
    const [nodes, setNodes, onNodesChange] = useNodesState([]);
    const [edges, setEdges, onEdgesChange] = useEdgesState([]);

    useEffect(() => {
        if (cfg && cfg.nodes && cfg.edges) {
            // Deep clone nodes to avoid mutating the prop (which is state in App.jsx)
            // JSON.parse/stringify is a quick way to deep clone simple data
            const deepClonedNodes = JSON.parse(JSON.stringify(cfg.nodes));
            const deepClonedEdges = JSON.parse(JSON.stringify(cfg.edges));

            const { nodes: layoutedNodes, edges: layoutedEdges } = getLayoutedElements(
                deepClonedNodes,
                deepClonedEdges
            );

            // Apply styling based on currentLine and executionStatus
            const styledNodes = layoutedNodes.map(node => {
                const newNode = { ...node };
                newNode.style = {
                    background: '#1f2937',
                    color: '#fff',
                    border: '1px solid #777',
                    width: 180
                };

                // We'll create a new data object to avoid mutating the original
                newNode.data = { ...node.data };

                // Highlight current line
                // Check if node matches current line AND file (if node has file info)
                const isCurrentLine = node.line === currentLine && (!node.file || !executionStatus?.currentFile || node.file === executionStatus.currentFile);

                if (isCurrentLine) {
                    newNode.style = {
                        ...newNode.style,
                        background: '#2563eb',
                        borderColor: '#60a5fa',
                        boxShadow: '0 0 10px #2563eb'
                    };
                }

                // Highlight based on execution status
                const statusKey = node.file ? `${node.file}:${node.line}` : node.line;

                if (executionStatus && executionStatus[statusKey]) {
                    const status = executionStatus[statusKey];
                    if (status.type === 'error') {
                        newNode.style = {
                            ...newNode.style,
                            background: '#7f1d1d',
                            borderColor: '#ef4444',
                            boxShadow: '0 0 10px #ef4444'
                        };

                        // Add error tooltip/indicator
                        // Ensure label is treated as a React Node
                        newNode.data.label = (
                            <div>
                                {node.data.label}
                                <div className="text-[10px] text-red-300 mt-1 bg-black/50 p-1 rounded">
                                    {status.error}
                                </div>
                            </div>
                        );
                    } else if (status.type === 'success') {
                        newNode.style = {
                            ...newNode.style,
                            background: '#064e3b',
                            borderColor: '#10b981'
                        };
                    }
                }

                return newNode;
            });

            setNodes(styledNodes);
            setEdges(layoutedEdges.map(e => ({
                ...e,
                markerEnd: { type: MarkerType.ArrowClosed },
                style: { stroke: '#555' }
            })));
        }
    }, [cfg, currentLine, executionStatus, setNodes, setEdges]);

    if (!cfg) return <div className="text-gray-500 text-sm">No Graph Available</div>;

    return (
        <div className="w-full h-full bg-gray-900">
            <ReactFlow
                nodes={nodes}
                edges={edges}
                onNodesChange={onNodesChange}
                onEdgesChange={onEdgesChange}
                fitView
                attributionPosition="bottom-right"
            >
                <Background color="#374151" gap={16} />
                <Controls className="bg-gray-800 border-gray-700 fill-gray-400" />
                <MiniMap
                    nodeColor={(n) => {
                        if (n.style?.background) return n.style.background;
                        return '#1f2937';
                    }}
                    maskColor="rgba(0, 0, 0, 0.6)"
                    className="bg-gray-800 border-gray-700"
                />
            </ReactFlow>
        </div>
    );
};

export default FlowGraph;
